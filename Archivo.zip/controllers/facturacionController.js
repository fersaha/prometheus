const axios = require('axios');
const bcrypt = require('bcryptjs');
const requestIp = require('request-ip');
const Tablas = require('../models/Tablas');
const  Sequelize  = require('sequelize');
const recursos = require('./recursosController');
const reduccionNombre = (nombreLargo) => {
    let usuario;
    const usuarios = nombreLargo.split(' ');
    if(usuarios.length > 1){
        usuario = `${usuarios[0]} ${usuarios[1].charAt(0)}.`;
    }else{
        usuario = usuarios[0];
    }
    return usuario;
  }
exports.cotizaciones = async (req,res) => {
    if(!req.session.userId){  
        res.redirect('/');
    }else{       
        const usuario = req.session.userId ;
        const privilegios = req.session.privilegios;
        const priv = privilegios.split('');
        const nombre = req.session.nombre;
        const usuarioReducido = await reduccionNombre(nombre);
        if(priv[23] !== '0'){ 
            res.render('cotizaciones', {
                nombrePagina: 'Cotizaciones',
                usuario,
                priv,
                titulo: 'Cotizaciones',
                usuarioReducido
            }); 
        }else{
            res.redirect('/');
        }         
    }
}

exports.consultaEnlazados = async (req,res) => {
        const Op = Sequelize.Op;
        const {id_admin} = (req.body);
        const {reg_bus} = (req.body);
        const {offset} = (req.body);
        const {reg_inp} = (req.body);
        const {factura} = (req.body);
        const {tipo_cliente} = (req.body);
        let adminWialon = [];
        const privilegios = req.session.privilegios;
        const priv = privilegios.split('');
        if(priv[21] === '6'){
            adminWialon = [1,2,3,4,5,6];
        }else if(priv[21] === '1'){
            adminWialon = [1];
        }else if(priv[21] === '2'){
               adminWialon = [2];
        }else if(priv[21] === '3'){
               adminWialon =[2];
        }else if(priv[21] === '4'){
                adminWialon =[4];
        }else if(priv[21] === '5'){
                adminWialon = [5];
        }
        let tipo;
        let fact;
        if(factura === 'all'){
            fact = '';
        }else{
            fact = factura;
        }
        if(tipo_cliente === 'all'){
            tipo = '';
        }else{
            tipo = tipo_cliente;
        }
        const offs = parseInt(offset);
        const limit = parseInt(reg_bus);
        const resultado = await Tablas.Correspondencia.findAll({
            include:[{
                model : Tablas.ClienteBind,
                where : {
                    id_admin,
                    nombre : {
                        [Op.like] : [`%${reg_inp}%`]
                    }
                },
            },{
                model : Tablas.ClienteWialon,
                where : {
                    id_admin :{
                        [Op.in] : adminWialon
                    }
                }
            },{
                model : Tablas.Almacen
            },{
                model : Tablas.Producto
            },{
                model : Tablas.Servicio
            }],
            where : {
                estatus : {
                    [Op.like] : [`%${fact}%`]
                },
                tipo_cliente : {
                    [Op.like] : [`%${tipo}%`]
                }
            },
            limit,
            offset : offs
        });
        const resultado2 = await Tablas.Correspondencia.findAll({
            include:[{
                model : Tablas.ClienteBind,
                where : {
                    id_admin,
                    nombre : {
                        [Op.like] : [`%${reg_inp}%`]
                    }
                },
            },{
                model : Tablas.ClienteWialon,
                where : {
                    id_admin :{
                        [Op.in] : adminWialon
                    }
                }
            },{
                model : Tablas.Almacen
            },{
                model : Tablas.Producto
            },{
                model : Tablas.Servicio
            }],
            where : {
                estatus : {
                    [Op.like] : [`%${fact}%`]
                },
                tipo_cliente : {
                    [Op.like] : [`%${tipo}%`]
                }
            },
        });
        res.send([resultado,resultado2.length])
    
}

exports.consultaEnlazado = async (req,res) => {
    const Op = Sequelize.Op;
    const {id_correspondencia} = (req.body);
    const resultado = await Tablas.Correspondencia.findOne({
        include:[{
            model : Tablas.ClienteBind,
        },{
            model : Tablas.ClienteWialon
        },{
            model : Tablas.Almacen
        },{
            model : Tablas.Producto
        },{
            model : Tablas.Servicio
        }],
        where : {
            id_correspondencia
        },
    });
    res.send(resultado)

}


exports.cambioEstadoFactura = async (req,res) => {
    const usuario_m = req.session.userId;
    const fecha_m = `${(await recursos.pedirFecha()).fecha} ${(await recursos.pedirFecha()).horario}`;
    const { id_correspondencia } = (req.body);
    const { estatus } = (req.body);
    const resultado = await Tablas.Correspondencia.update({
        estatus ,
        usuario_m,
        fecha_m
        },{
            where : {
                id_correspondencia
            }
        });
    if(!resultado) return next();
    res.status(200).send('Se cambió es estatus de facturación');
}

exports.actualizarEnlazados = async (req,res,next) => {
    const Op = Sequelize.Op;
    const usuario_m = req.session.userId;
    const fecha_m = `${(await recursos.pedirFecha()).fecha} ${(await recursos.pedirFecha()).horario}`;
    const { id_correspondencia } = (req.body);
    const { precio } = (req.body);
    const { unidades } = (req.body);
    let unidadesD =0;
    const wialon = await Tablas.Correspondencia.findOne({
        where : {id_correspondencia},
        include : {
            model : Tablas.ClienteWialon
        }
    })
    const existe = await Tablas.Correspondencia.findAll({
        where : {
            id_wialon : wialon.id_Wialon,
            id_correspondencia : {
                [Op.ne] : id_correspondencia
            }
        },
        include : [{
            model : Tablas.ClienteBind
        },{
            model : Tablas.ClienteWialon
        }]
    });
    if(!unidades || isNaN(unidades)){
        res.status(201).send(`El número de unidades no es válido`);
        return next();
    }
    if(unidades % 1 !== 0) {
        res.status(201).send(`El número de unidades debe ser entero`);
        return next();
    }
    if(!precio || isNaN(precio)){
        res.status(201).send(`El precio no es válido`);
        return next();
    }
    if(existe.length){
        for(let exis of existe){
            unidadesD += parseInt(exis.unidades);
        }
        if(parseInt(wialon.cat_wialoncliente.unidades) < (parseInt(unidades) + unidadesD)){
            //res.send(`Ya se encuentra enlazado a Cliente bind : ${existe.cat_bindcliente.nombre}`);
            res.status(201).send(`Las unidades totales : ${parseInt(wialon.cat_wialoncliente.unidades)} 
            son menores a las que se van a facturar : ${parseInt(unidades) + unidadesD}`);
            return next();
        }
    }else{       
        if(parseInt(wialon.cat_wialoncliente.unidades) < parseInt(unidades)){
            //res.send(`Ya se encuentra enlazado a Cliente bind : ${existe.cat_bindcliente.nombre}`);
            res.status(201).send(`Las unidades totales : ${parseInt(wialon.cat_wialoncliente.unidades)} 
            son menores a las que se van a facturar : ${parseInt(unidades)}`);
            return next();
        }
    }
    const resultado = await Tablas.Correspondencia.update({
        usuario_m,
        fecha_m,
        unidades : parseInt(unidades),
        precio : parseFloat(precio)
        },{
            where : {
                id_correspondencia
            }
        });
    if(!resultado) return next();
    res.status(200).send('Se actualizó satisfactoriamente');
}

exports.consultaAFacturar = async (req,res) => {
    const Op = Sequelize.Op;
    const {id_admin} = (req.body);
    const {reg_inp} = (req.body);
    const {tipo_cliente} = (req.body);
    let tipo;
    if(tipo_cliente === 'all'){
       res.send(['2','Especifique distribuidor o cliente']);
       return;
    }
    const resultado = await Tablas.Correspondencia.findAll({
        include:[{
            model : Tablas.ClienteBind,
            attributes : ['nombre','nombre_legal','rfc'],
            where : {
                id_admin,
                nombre : {
                    [Op.like] : [`%${reg_inp}%`]
                }
            },
        },{
            model : Tablas.ClienteWialon,
            attributes : ['nombre']
        }],
        attributes : ['estatus','unidades','precio','id_correspondencia'],
        where : {
            estatus : '1',
            tipo_cliente 
        },
    });
    res.send(resultado);
}

exports.generarRemision = async (req,res) => {
    const Op = Sequelize.Op;
    const {list} = (req.body);  
    let admin;
    const idultimo = await Tablas.TCinformacion.findOne({
        attributes: [
            [Sequelize.fn('max', Sequelize.col('id_tcinformacion')),'id_tcinformacion']
        ]
    });
    const cambio = await Tablas.TCinformacion.findOne({
        where : {
            id_tcinformacion : idultimo.id_tcinformacion
        }
    });
    //JSON.stringify
    const resultado = await Tablas.Correspondencia.findOne({
        include:[{
            model : Tablas.ClienteBind,
            attributes : ['id_cliente'],
            include :[{
                model : Tablas.Admin,
                attributes : ['nombre'],
            },{
                model : Tablas.InformacionCliente,
                attributes : ['PriceListID'],
            }]               
        },{
            model : Tablas.ClienteWialon
        },{
            model : Tablas.Almacen,
            attributes : ['id_locacion','id'],
        },{
            model : Tablas.Producto,
            attributes : ['id']
        },{
            model : Tablas.Servicio
        }],
        attributes : ['uso','unidades','precio'],
        where : {
            id_correspondencia : list
        }
    });      
    admin = resultado.cat_bindcliente.cat_admin.nombre;  
    const precioFinal =  (resultado.precio * cambio.afacturar).toFixed(2);
    const dato = {
        admin ,
        client_id : resultado.cat_bindcliente.id_cliente,
        location_id : resultado.cat_almacene.id_locacion,
        warehouse_id : resultado.cat_almacene.id,
        cfdi_use : resultado.uso,
        pricelist_id : resultado.cat_bindcliente.cat_informacioncliente.PriceListID,
        product_id : resultado.cat_producto.id,
        precio_ajustado :precioFinal,
        product_qty : parseInt(resultado.unidades)
    };              
    const str = JSON.stringify(dato);
    const usuario_a = req.session.userId;
    const fecha_a = `${(await recursos.pedirFecha()).fecha} ${(await recursos.pedirFecha()).horario}`;
    let errorAx,remision;
    console.log(dato)
    await axios.post(`http://201.150.1.66/apifacturas/crear/remision`,{
        admin ,
        client_id : resultado.cat_bindcliente.id_cliente,
        location_id : resultado.cat_almacene.id_locacion,
        warehouse_id : resultado.cat_almacene.id,
        cfdi_use : resultado.uso,
        pricelist_id : resultado.cat_bindcliente.cat_informacioncliente.PriceListID,
        product_id : resultado.cat_producto.id,
        precio_ajustado :precioFinal,
        product_qty : parseInt(resultado.unidades)
        },{ 
        headers : {'Content-Type': 'application/json',
                    'Authorization': 'Bearer ' + process.env.TOKEN}
        })
        .then(
            async resultadoFact => {
                console.log(resultadoFact);
                remision = await Tablas.BitacoraFactura.create({
                    unidades : resultado.unidades,
                    precio : parseFloat(resultado.precio).toFixed(2),
                    respuesta : resultadoFact.data.data.respuesta,
                    error : resultadoFact.data.data.error,
                    estatus : '1',
                    fecha_a,
                    usuario_a,
                    id_correspondencia : list,
                    id_tc : cambio.id_tcinformacion
                });  
                let errors;
                if(resultadoFact.data.data.error){
                    errors = '1'
                }else {
                    errors = '0'
                }  
                res.send(['1',list,errors]);
            })
        .catch(
            async error => {
                console.log(error);
                if(error.message){
                    errorAx = error.message;
                }else{
                    errorAx = `No disponible`;
                }
                remision = await Tablas.BitacoraFactura.create({
                    unidades : resultado.unidades,
                    precio : parseFloat(resultado.precio).toFixed(2),
                    respuesta : errorAx,
                    error : true,
                    estatus : '1',
                    fecha_a,
                    usuario_a,
                    id_correspondencia : list,
                    id_tc : cambio.id_tcinformacion
                }); 
                res.send([error,list]);
                return;
            })
   /* const resultadoFact = { 'data' : {
                "error" : false,
                "respuesta" : "kjdshjakshda",
                "client_id" : resultado.cat_bindcliente.id_cliente
        }
    }    */
    //console.log(resultadoFact); 
}

exports.generarFactura = async (req,res) => {
    const Op = Sequelize.Op;
    const {list} = (req.body);  
    let admin;
    const resultado = await Tablas.Correspondencia.findOne({
        include:[{
            model : Tablas.ClienteBind,
            attributes : ['id_cliente'],
            include :[{
                model : Tablas.Admin,
                attributes : ['nombre'],
            },{
                model : Tablas.InformacionCliente,
                attributes : ['PriceListID'],
            }]               
        },{
            model : Tablas.ClienteWialon
        },{
            model : Tablas.Almacen,
            attributes : ['id_locacion','id'],
        },{
            model : Tablas.Producto,
            attributes : ['id']
        },{
            model : Tablas.Servicio
        }],
        attributes : ['uso','unidades','precio'],
        where : {
            id_correspondencia : list
        }
    });      
    admin = resultado.cat_bindcliente.cat_admin.nombre;  
    const dato = {             
        admin,
        client_id : resultado.cat_bindcliente.id_cliente,
        location_id : resultado.cat_almacene.id_locacion,
        warehouse_id : resultado.cat_almacene.id,
        cfdi_use : resultado.uso,
        pricelist_id : resultado.cat_bindcliente.cat_informacioncliente.PriceListID,
        product_id : resultado.cat_producto.id,
        precio_bruto : parseFloat(resultado.precio).toFixed(2),
        product_qty : parseInt(resultado.unidades)
    };              
    const str = JSON.stringify(dato);
    const usuario_a = req.session.userId;
    const fecha_a = `${(await recursos.pedirFecha()).fecha} ${(await recursos.pedirFecha()).horario}`;
    let errorAx,remision;
    await axios.post(`http://201.150.1.66/apifacturas/crear/factura`,{
        admin,
        client_id : resultado.cat_bindcliente.id_cliente,
        location_id : resultado.cat_almacene.id_locacion,
        warehouse_id : resultado.cat_almacene.id,
        cfdi_use : resultado.uso,
        pricelist_id : resultado.cat_bindcliente.cat_informacioncliente.PriceListID,
        product_id : resultado.cat_producto.id,
        precio_bruto : parseFloat(resultado.precio).toFixed(2),
        product_qty : parseInt(resultado.unidades)
        },{ 
        headers : {'Content-Type': 'application/json',
                    'Authorization': 'Bearer ' + process.env.TOKEN}
        })
        .then(
            async resultadoFact => {
                console.log(resultadoFact);
                remision = await Tablas.BitacoraFactura.create({
                    unidades : resultado.unidades,
                    precio : parseFloat(resultado.precio).toFixed(2),
                    respuesta : resultadoFact.data.data.respuesta,
                    error : resultadoFact.data.data.error,
                    estatus : '1',
                    fecha_a,
                    usuario_a,
                    id_correspondencia : list,
                    id_tc : 1
                });  
                let errors;
                if(resultadoFact.data.data.error){
                    errors = '1'
                }else {
                    errors = '0'
                }  
                res.send(['1',list,errors]);
            })
        .catch(
            async error => {
                console.log(error);
                if(error.message){
                    errorAx = error.message;
                }else{
                    errorAx = `No disponible`;
                }
                remision = await Tablas.BitacoraFactura.create({
                    unidades : resultado.unidades,
                    precio : parseFloat(resultado.precio).toFixed(2),
                    respuesta : errorAx,
                    error : true,
                    estatus : '1',
                    fecha_a,
                    usuario_a,
                    id_correspondencia : list,
                    id_tc : 1
                }); 
                res.send([error,list]);
                return;
            })

    }    
     
   
    


exports.cambiarEstatusBitacora = async (req,res) => {
    const usuario_m = req.session.userId;
    const fecha_m = `${(await recursos.pedirFecha()).fecha} ${(await recursos.pedirFecha()).horario}`;
    const Op = Sequelize.Op;
    const {id_bitacora_factura} = (req.body);
    await Tablas.BitacoraFactura.update({
        estatus : '1',
        usuario_m,
        fecha_m
    },{
        where : {
            id_bitacora_factura
        }
    });
    res.send('1');
}



/*DASHBOARD*/
exports.dashboard = async (req,res) => {
    if(!req.session.userId){  
        res.redirect('/');
    }else{       
        const usuario = req.session.userId ;
        const privilegios = req.session.privilegios;
        const priv = privilegios.split('');
        if(priv[19] !== '0'){ 
            res.render('dashboard', {
                nombrePagina: 'Dashboard',
                usuario,
                priv,
                titulo: 'Dashboard'
            }); 
        }else{
            res.redirect('/');
        }         
    }
}

exports.cambioDolar = async (req,res) => {    
    const cambio = await axios.get(`http://201.150.1.66/apifacturas/dolar/cambio`,{ 
    headers : {'Content-Type': 'application/json',
                'Authorization': 'Bearer ' + process.env.TOKEN}
    });
    res.send(cambio.data.data)
}

exports.tcfacturar = async (req,res) => {    
    const idultimo = await Tablas.TCinformacion.findOne({
        attributes: [
            [Sequelize.fn('max', Sequelize.col('id_tcinformacion')),'id_tcinformacion']
        ]
    });
    const ultimotc = await Tablas.TCinformacion.findOne({
        where : {
            id_tcinformacion : idultimo.id_tcinformacion
        }
    });
    res.send(ultimotc)
}

exports.ajustePorcentaje = async (req,res) => {    
    const {porcentaje} = (req.body);
    const {tcbmx} = (req.body);
    const {tcajustado} = (req.body);
    const {actualizacion} = (req.body);
    const actualiz = actualizacion.split('/');
    const actualizacionCorrecta = `${actualiz[2]}-${actualiz[1]}-${actualiz[0]}`;
    const usuario_a = req.session.userId;
    const fecha_a= `${(await recursos.pedirFecha()).fecha} ${(await recursos.pedirFecha()).horario}`;

    const valor1 =  parseFloat(porcentaje) / 100;
    const valor2 = valor1 * parseFloat(tcbmx);
    const afacturar = valor2 + parseFloat(tcbmx);

    const resultado = await Tablas.TCinformacion.create({
        porcentaje,
        tcbmx,
        tcajustado,
        actualizacion : actualizacionCorrecta,
        afacturar,
        estatus : '1',
        usuario_a,
        fecha_a
    })
    if(!resultado) return next();
    res.status(200).send('Se ajustaron los valores de TC satisfactoriamente');
}
/*-----------------*/


/*FACTURAS*/
exports.facturas = async (req,res) => {
    if(!req.session.userId){  
        res.redirect('/');
    }else{       
        const usuario = req.session.userId ;
        const privilegios = req.session.privilegios;
        const priv = privilegios.split('');
        if(priv[22] !== '0'){ 
            res.render('facturas', {
                nombrePagina: 'Facturas',
                usuario,
                priv,
                titulo: 'Facturas'
            }); 
        }else{
            res.redirect('/');
        }         
    }
}

exports.consultaFacturas = async (req,res) => {
    const Op = Sequelize.Op;
    const {id_admin} = (req.body);
    const {reg_bus} = (req.body);
    const {offset} = (req.body);
    const {reg_inp} = (req.body);
    const {mes_fact} = (req.body);
    const {anho_fact} = (req.body);
    const {tipo_cliente} = (req.body);
    let tipo;
    let fecha;
    if(tipo_cliente === 'all'){
        tipo = '';
    }else{
        tipo = tipo_cliente;
    }
    if(anho_fact === "all"){
        fecha = mes_fact
    }else{
        fecha= `${anho_fact}${mes_fact}`;
    }
    const offs = parseInt(offset);
    const limit = parseInt(reg_bus);
    const resultado = await Tablas.BitacoraFactura.findAll({
        attributes : ['id_bitacora_factura','error','fecha_a'],
        include:[{
            model : Tablas.Correspondencia,
            attributes : ['tipo_cliente'],
            where : {
                tipo_cliente : {
                    [Op.like] : [`%${tipo}%`]
                }
            },
            include : [{
                model : Tablas.ClienteBind,
                attributes : ['nombre','nombre_legal'],
                where : {
                    nombre : {
                        [Op.like] : [`%${reg_inp}%`]
                    },
                    id_admin
                }
            },{
                model : Tablas.ClienteWialon,
                attributes : ['nombre']
            }]
        }],
        where : {
            fecha_a : {
                [Op.like] : [`%${fecha}%`]
            },
            estatus : {
                [Op.notIn] : ['3']
            }
        },
        limit,
        offset : offs
    });

    const resultado2 = await Tablas.BitacoraFactura.count({
        include:[{
            model : Tablas.Correspondencia,
            where : {
                tipo_cliente : {
                    [Op.like] : [`%${tipo}%`]
                }
            },
            include : [{
                model : Tablas.ClienteBind,
                where : {
                    nombre : {
                        [Op.like] : [`%${reg_inp}%`]
                    },
                    id_admin
                }
            },{
                model : Tablas.ClienteWialon
            }]
        }],
        where : {
            fecha_a : {
                [Op.like] : [`%${fecha}%`]
            },
            estatus : {
                [Op.notIn] : ['3']
            }
        }
      });
     const res2Count = String(resultado2);
    res.send([resultado,res2Count])

}

exports.descargaFactura = async (req,res) => {
    const {id_bitacora_factura} = (req.body);
    const consulta = await Tablas.BitacoraFactura.findOne({
        include : [{
            model : Tablas.Correspondencia,
            include : {
                model : Tablas.ClienteBind,
                include : {
                    model : Tablas.Admin
                }
            }
        }], 
        where : {
            id_bitacora_factura
        }        
    });
    const admin = consulta.cat_correspondencia.cat_bindcliente.cat_admin.nombre;
    const tipo = consulta.cat_correspondencia.tipo_cliente;
    const factura_idSplit = consulta.respuesta.split('"');    
    const id_factura = factura_idSplit[1];
    const datos = {
        admin,
        id_factura,
        tipo
    }
    res.send(datos)

}
exports.verErrorFactura = async (req,res) => {
    const {id_bitacora_factura} = (req.body);
    const consulta = await Tablas.BitacoraFactura.findOne({
        where : {
            id_bitacora_factura
        }        
    });
    res.send(consulta.respuesta)
}

exports.consultaUnidadesDesglose = async (req,res) => {
    const Op = Sequelize.Op;
    const {id_admin} = (req.body);
    const {tipo_cliente} = (req.body);
    let cliente;
    if(tipo_cliente === 'all'){
        cliente = '';
    }else{
        cliente = tipo_cliente;
    }
    let arreglo = [];
    const consulta = await Tablas.Almacen.findAll({
        where : {
            id_admin
        },
        attributes : ['id_almacen','nombre']
    });
    for(let almacen of consulta){
        const suma = await Tablas.Correspondencia.sum('unidades', { 
            where: { 
                id_almacen: almacen.id_almacen,
                estatus : '1',
                tipo_cliente : {
                    [Op.like] : `%${cliente}%`
                }
            } 
        }); 
        arreglo.push({
            nombre : almacen.nombre,
            unidades : suma
        });
    }
    res.send(arreglo);
}
/*-----------------*/