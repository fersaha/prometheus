import axios from 'axios';
import { v4 as uuidv4 } from 'uuid';
const espacioCotizaciones = document.querySelector('.espacioCotizaciones');
const espacioProductosCotizacion = document.querySelector('.espacioProductosCotizacion');
const botonNuevaCotizacion = document.querySelector('#botonNuevaCotizacion');
const botonAgregarProducto = document.querySelector('.botonAgregarProducto');
//COTIZACIONES
const consultaCotizaciones = () =>{
    console.log('PEPITO');
}

const consultaCarritoCotizacion = async () =>{
    const productos = await axios.get('/consultaComboProductos');
    let combo = `<select  class="form-control" id="id_producto">`;
    for(let producto of productos.data){
        combo += `<option value="${producto.id_producto}">${producto.nombre}</option>`;
    }
    combo += `</select>`;
    document.querySelector('#comboProductos').innerHTML = combo;
    let contenido;
    const carrito = localStorage.getItem('carrito');
    if(JSON.parse(carrito).length){
       const carritoObj = JSON.parse(carrito);
       let tabla = `<table class="table table-striped">
                        <tr>
                            <th></th>
                        </tr>`;
       for(let producto of carritoObj){

       }
    }else{
        contenido = `<div class="card">
        <div class="card-body">
          Aún no hay productos.
        </div>
      </div>`;
      const esqueleto  = [];
      const esqueletoStr = JSON.stringify(esqueleto);
      localStorage.setItem('carrito',esqueletoStr);
    }
    espacioProductosCotizacion.innerHTML = contenido;
};
if(espacioCotizaciones){    
    consultaCotizaciones();
}

if(botonNuevaCotizacion){
    botonNuevaCotizacion.addEventListener('click', e=>{
        consultaCarritoCotizacion();
    });
}

if(botonAgregarProducto){
    botonAgregarProducto.addEventListener('click', async e=>{
        const producto = document.querySelector('#id_producto').nodeValue;
        const detalles  = await axios.get(`/consultaProductoId/${producto}`);
        const carrito = localStorage.getItem('carrito');
        const carritoObj = JSON.parse(carrito);
        let carritoN = [];
        if(carritoObj.length){
            for(let objeto of carritoObj){
                carritoN.push(objeto);
            }
            const productoObj  = {
                nombre : detalles.data.nombre,
                key : uuidv4(),
                costo : detalles.data.costo,
                id : detalles.data.id_producto
            }
            carritoN.push(productoObj);
            localStorage.setItem('carrito',JSON.stringify(carritoN));
            consultaCarritoCotizacion();
        }else{
            const productoObj  = {
                nombre : detalles.data.nombre,
                key : uuidv4(),
                costo : detalles.data.costo,
                id : detalles.data.id_producto
            }
            carritoN.push(productoObj);
            localStorage.setItem('carrito',JSON.stringify(carritoN));
            consultaCarritoCotizacion();
        }
    });
}
