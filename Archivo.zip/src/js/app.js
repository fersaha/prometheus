import facturacion from './modulos/facturacion';
import notificaciones from './modulos/notificaciones';
import reportes from './modulos/reportes';
import documentos from './modulos/documentos';
import catalogos from './modulos/catalogos';
import ventas from './modulos/ventas';
import main from './modulos/main';